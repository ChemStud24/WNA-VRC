/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\jdbla                                            */
/*    Created:      Tue Jan 07 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// WheelR1              motor29       B               
// WheelR2              motor29       C               
// WheelL1              motor29       D               
// WheelL2              motor29       E               
// Controller1          controller                    
// ArmRight             motor         1               
// ArmLeft              motor         2               
// Clawmotor            motor29       F               
// ArmRight2            motor         3               
// ArmLeft2             motor         4               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
double RightSpeed;
double LeftSpeed;
bool ClawSpeedR;
bool ClawSpeedL;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  while(true){
RightSpeed=Controller1.Axis2.value();
LeftSpeed=Controller1.Axis3.value();
ClawSpeedR=Controller1.ButtonRight.pressing();
ClawSpeedL=Controller1.ButtonLeft.pressing();
if(RightSpeed>0){
WheelR1.spin(forward,RightSpeed,percent);
WheelR2.spin(forward,RightSpeed,percent);
}else{
  WheelR1.spin(reverse,-RightSpeed,percent);
  WheelR2.spin(reverse,-RightSpeed,percent);
}
if(LeftSpeed>0){
WheelL1.spin(forward,LeftSpeed,percent);
WheelL2.spin(forward,LeftSpeed,percent);
}else{
  WheelL1.spin(reverse,-LeftSpeed,percent);
  WheelL2.spin(reverse,-LeftSpeed,percent);
}
if(ClawSpeedR){
  Clawmotor.spin(reverse,100,rpm);
}
else if(ClawSpeedL){
  Clawmotor.spin(reverse,-100,percent);
}
else{
  Clawmotor.spin(reverse,0,rpm);
}
  }

ArmRight.spin(reverse,-200,rpm);
ArmRight.spin(forward,200,rpm);
ArmLeft.spin(forward,200,rpm);
ArmLeft.spin(reverse,-200,rpm);
ArmLeft.setVelocity(200,rpm);
ArmLeft.setVelocity(-200,rpm);
ArmRight.setVelocity(200,rpm);
ArmRight.setVelocity(-200,rpm);

}
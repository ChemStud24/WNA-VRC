#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor29 WheelR1 = motor29(Brain.ThreeWirePort.B, true);
motor29 WheelR2 = motor29(Brain.ThreeWirePort.C, true);
motor29 WheelL1 = motor29(Brain.ThreeWirePort.D, false);
motor29 WheelL2 = motor29(Brain.ThreeWirePort.E, false);
controller Controller1 = controller(primary);
motor ArmRight = motor(PORT1, ratio18_1, false);
motor ArmLeft = motor(PORT2, ratio18_1, true);
motor29 Clawmotor = motor29(Brain.ThreeWirePort.F, true);
motor ArmRight2 = motor(PORT3, ratio18_1, false);
motor ArmLeft2 = motor(PORT4, ratio18_1, false);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Text.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}